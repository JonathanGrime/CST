<?php



error_reporting(E_ERROR);
//Connection To MYSQL DataBase
//Function called in external scripts

function DBConnect(){
//add further global vars at the end of the line below once you have created them in the database admin tool
global $Host, $User, $DBPassword, $DBName, $table_1 ;

$Host = "mysql.scm.tees.ac.uk";
$User = "q5079936";
$DBPassword = "djHDWKC**u-B";
$DBName = "q5079936";
//add links to your new tables here as well

$table_1 = "Users";





}//close function







?>
