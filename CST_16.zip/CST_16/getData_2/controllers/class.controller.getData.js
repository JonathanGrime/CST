$(function() {
    'use strict';


    function getAllData() {

        //Call to get the data
        var getData = $.get("https://u0018370.scm.tees.ac.uk/CST/demos/lect8/models/model.class.getData.php?action=getAllData",



            function(data) {

                //inspect the incoming data objects
                console.log(data);

                var sectorDetails = [];


                var j = 0;
                var dataLength = data.tripData.length;



                for (var i = 0; i < data.tripData.length; i++) {

                    var item = data.tripData[i];


                    var Itin_id = item.Itin_id;
                    var tripName = item.tripName;



                    //inner for loop for related data

                    for (var j = 0; j < data.tripData[i].sectorData.length; j++) {

                        var sectorName = data.tripData[i].sectorData[j].sectorName ;
                        var sectorImg = "img/"+data.tripData[i].sectorData[j].imgPath ;

                        var sectorNumShow = j + 1;

                        sectorDetails[j] = '<li><img src="'+sectorImg+'" height="100" width="100" /> sector: ' + sectorNumShow + ': ' + sectorName + '</li>';
                        var displaySectors = sectorDetails.join("");
                        //alert(data.tripData[i].sectorData[j].sectorName);


                    } //close inner loop


                    var tripDetails = '<li>Trip: ' + Itin_id + '&nbsp;&nbsp;&nbsp;<span class="Itin">Trip Name: ' + tripName + '</span><ul>' + displaySectors + '</ul></li>';


                    //push data into dashboard
                    $('#tripData').append(tripDetails);



                } //close outer loop


            }, "json"); //close GET


    } //close function


    getAllData();

}); //close base function
