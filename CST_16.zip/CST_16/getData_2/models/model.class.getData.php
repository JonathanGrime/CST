<?php
session_start();
/**
 *
 *
 * The purpose of the file is to provide a number web services. This file uses JSON to encode data back to the controller in an object named 'carData'.
 *
 * PHP version 5.3
 *

 * @author  Original Author <you@live.tees.ac.uk>

 * @version SVN:1.0

 */

header('Content-Type: application/json');

include "class.model.common.php";

DBConnect();

$Link = mysqli_connect($Host, $User, $DBPassword, $DBName);


$action = $_GET['action'];

if($action=="getAllData"){

getAllData($Host, $User, $DBPassword, $DBName, $table_1, $table_2, $table_3, $table_4, $table_5 );

}




//1.
function getAllData($Host, $User, $DBPassword, $DBName, $table_1, $table_2, $table_3, $table_4, $table_5 ){

$Link = mysqli_connect($Host, $User, $DBPassword, $DBName);


$Query = "SELECT * FROM $table_2 WHERE Users_id = '1'";



	if($Result = mysqli_query($Link, $Query)){


	$tripData = array();
	$sectorData = array();


	while($row = mysqli_fetch_array($Result)){

	//Get the data for the category
	$Itin_id = $row['Itin_id'];
	$tripName = $row['tripName'];




		//Nested Query to return the related data based on foreign key
		$Query2 = "SELECT * FROM $table_3 WHERE Itin_id ='".$Itin_id."' ";

		if($Result2 = mysqli_query($Link, $Query2)){
			while($row2 = mysqli_fetch_array($Result2)){

			$sector_id = $row2['Sector_id'];
			$sectorName = $row2['sectorName'];
			$TripImages_id = $row2['TripImages_id'];

				$Query3 = "SELECT * FROM $table_5 WHERE TripImages_id ='".$TripImages_id."' ";
				if($Result3 = mysqli_query($Link, $Query3)){

					$row3 = mysqli_fetch_array($Result3);

					$imgPath = $row3['imgPath'];

				}

				//Create an array object
				$sectorData[] = array('sector_id'=>$sector_id, 'sectorName'=>$sectorName, 'imgPath'=>$imgPath);

		}//close while

	}//close conditional





	//Create an array object
	$tripData[] = array('Itin_id'=>$Itin_id, 'tripName'=>$tripName,'sectorData'=>$sectorData);



	}//close while loop

			//Send data to the Controller function


		echo json_encode(array('action'=>'success','tripData'=>$tripData, 'console.log'=>$Query2));
		exit();

		}else{

		//Send Error for the first query
		echo json_encode(array('action'=>'mysql error', 'console.log'=>$Query2));
		exit();

		}//close condition

}//Close  Function



?>
